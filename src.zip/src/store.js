const state = {

    // server_domain: "http://localhost:3000",

    server_domain: "http://liel-bin.cs.bgu.ac.il",
    

};